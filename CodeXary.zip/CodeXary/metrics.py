# metrics.py
import psutil, time
from db import get_db_connection

def read_thresholds():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT key, value FROM config")
    rows = cur.fetchall()
    conn.close()
    cfg = {r['key']: float(r['value']) for r in rows}
    return cfg

def check_and_store_metrics():
    """
    Collects CPU and memory usage, stores reading in DB,
    and generates alerts if thresholds are breached.
    Returns (metrics_dict, alerts_list)
    """
    cpu = psutil.cpu_percent(interval=1)
    mem = psutil.virtual_memory().percent
    ts = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())

    # store metrics
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("INSERT INTO metrics (cpu, memory, timestamp) VALUES (?, ?, ?)", (cpu, mem, ts))
    conn.commit()

    # check thresholds
    cfg = read_thresholds()
    cpu_threshold = cfg.get('CPU_THRESHOLD', 80)
    mem_threshold = cfg.get('MEM_THRESHOLD', 75)

    alerts = []
    if cpu > cpu_threshold:
        cur.execute("INSERT INTO alerts (type, value, timestamp) VALUES (?, ?, ?)",
                    ("CPU", cpu, ts))
        alerts.append({"type": "CPU", "value": cpu, "timestamp": ts})
    if mem > mem_threshold:
        cur.execute("INSERT INTO alerts (type, value, timestamp) VALUES (?, ?, ?)",
                    ("Memory", mem, ts))
        alerts.append({"type": "Memory", "value": mem, "timestamp": ts})

    conn.commit()
    conn.close()

    metrics = {"cpu": cpu, "memory": mem, "timestamp": ts}
    return metrics, alerts

def get_recent_metrics(limit=50):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT cpu, memory, timestamp FROM metrics ORDER BY id DESC LIMIT ?", (limit,))
    rows = cur.fetchall()
    conn.close()
    # return in chronological order (oldest first)
    rows = list(reversed(rows))
    return [{"cpu": r["cpu"], "memory": r["memory"], "timestamp": r["timestamp"]} for r in rows]

def get_recent_alerts(limit=50):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT id, type, value, timestamp FROM alerts ORDER BY id DESC LIMIT ?", (limit,))
    rows = cur.fetchall()
    conn.close()
    rows = list(reversed(rows))
    return [{"id": r["id"], "type": r["type"], "value": r["value"], "timestamp": r["timestamp"]} for r in rows]

def update_thresholds(cpu_threshold=None, mem_threshold=None):
    conn = get_db_connection()
    cur = conn.cursor()
    if cpu_threshold is not None:
        cur.execute("INSERT OR REPLACE INTO config (key, value) VALUES (?, ?)", ("CPU_THRESHOLD", str(cpu_threshold)))
    if mem_threshold is not None:
        cur.execute("INSERT OR REPLACE INTO config (key, value) VALUES (?, ?)", ("MEM_THRESHOLD", str(mem_threshold)))
    conn.commit()
    conn.close()

def get_thresholds():
    cfg = read_thresholds()
    return {"cpu_threshold": cfg.get("CPU_THRESHOLD", 80), "mem_threshold": cfg.get("MEM_THRESHOLD", 75)}
