# db.py
import sqlite3
from contextlib import closing

DB_PATH = "alerts.db"

def init_db():
    with closing(sqlite3.connect(DB_PATH)) as conn:
        c = conn.cursor()
        # metrics: store cpu and memory readings with timestamp
        c.execute('''
            CREATE TABLE IF NOT EXISTS metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                cpu REAL,
                memory REAL,
                timestamp TEXT
            )
        ''')
        # alerts: type, value, timestamp
        c.execute('''
            CREATE TABLE IF NOT EXISTS alerts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                type TEXT,
                value REAL,
                timestamp TEXT
            )
        ''')
        # config: key-value store (e.g., CPU_THRESHOLD, MEM_THRESHOLD)
        c.execute('''
            CREATE TABLE IF NOT EXISTS config (
                key TEXT PRIMARY KEY,
                value TEXT
            )
        ''')
        # initial thresholds if not set
        c.execute("INSERT OR IGNORE INTO config (key, value) VALUES (?, ?)", ("CPU_THRESHOLD", "80"))
        c.execute("INSERT OR IGNORE INTO config (key, value) VALUES (?, ?)", ("MEM_THRESHOLD", "75"))
        conn.commit()

def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn
