// static/js/dashboard.js
let token = null;
const setTokenBtn = document.getElementById('setToken');
setTokenBtn.onclick = () => {
  token = document.getElementById('token').value.trim();
  if (token) {
    alert('Token set. Dashboard will use this token for API calls.');
    loadAll();
  }
};

function authHeaders() {
  return { 'Content-Type': 'application/json', 'Authorization': token };
}

async function callApi(path, opts = {}) {
  if (!token) { alert('Set token first'); throw 'no-token'; }
  opts.headers = Object.assign(opts.headers || {}, authHeaders());
  const res = await fetch(path, opts);
  if (!res.ok) {
    const text = await res.text();
    alert('API error: ' + res.status + ' - ' + text);
    throw res;
  }
  return res.json();
}

let metricsChart = null;
async function drawMetrics() {
  const data = await callApi('/api/metrics-history?limit=50');
  const labels = data.map(d => d.timestamp);
  const cpu = data.map(d => d.cpu);
  const mem = data.map(d => d.memory);

  const ctx = document.getElementById('metricsChart').getContext('2d');
  if (metricsChart) metricsChart.destroy();
  metricsChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: labels,
      datasets: [
        { label: 'CPU %', data: cpu, fill: false, tension: 0.1 },
        { label: 'Memory %', data: mem, fill: false, tension: 0.1 }
      ]
    },
    options: {
      scales: { y: { beginAtZero: true, suggestedMax: 100 } }
    }
  });
}

async function loadAlerts() {
  const alerts = await callApi('/api/alerts?limit=200');
  const tbody = document.querySelector('#alertsTable tbody');
  tbody.innerHTML = '';
  alerts.forEach(a => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${a.id}</td><td>${a.type}</td><td>${a.value}</td><td>${a.timestamp}</td>`;
    tbody.appendChild(tr);
  });
}

async function loadThresholds() {
  const cfg = await callApi('/api/config');
  document.querySelector('#thresholdForm [name="cpu"]').value = cfg.cpu_threshold;
  document.querySelector('#thresholdForm [name="mem"]').value = cfg.mem_threshold;
  document.getElementById('currentThresholds').innerText = `CPU: ${cfg.cpu_threshold}%, Memory: ${cfg.mem_threshold}%`;
}

document.getElementById('thresholdForm').onsubmit = async (e) => {
  e.preventDefault();
  const cpu = parseFloat(e.target.cpu.value);
  const mem = parseFloat(e.target.mem.value);
  await callApi('/api/config', {
    method: 'POST',
    body: JSON.stringify({ cpu_threshold: cpu, mem_threshold: mem })
  });
  alert('Thresholds updated');
  loadThresholds();
};

document.getElementById('refreshMetrics').onclick = async () => {
  // call the collect-metrics endpoint to trigger a new reading
  await callApi('/api/collect-metrics', { method: 'POST' });
  await loadAll();
};

async function loadAll() {
  try {
    await drawMetrics();
    await loadAlerts();
    await loadThresholds();
  } catch (e) {
    console.error(e);
  }
}

// auto refresh every 10s (if token set)
setInterval(() => { if (token) loadAll(); }, 10000);
