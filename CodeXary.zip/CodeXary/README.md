# CodeXray — Observability & Security Microservice

## Overview
Flask-based microservice that:
- Parses logs (Phase 1)
- User registration/login + session token (Phase 2)
- Collects CPU & memory metrics, generates alerts, stores in SQLite (Phase 3)
- Summary & reporting APIs (Phase 4)
- Web dashboard (bonus): visualizes metrics, shows alerts, and allows threshold config

## Setup
1. Clone the project
2. Create virtualenv (optional) and install:
pip install -r requirements.txt

markdown
Copy code
3. Run:
python app.py

pgsql
Copy code
4. Open http://127.0.0.1:5000

## Quick usage
1. Register: `POST /api/register` with JSON `{"username":"user","password":"pass"}`
2. Login: `POST /api/login` get `session_token`
3. In dashboard (`/dashboard`) paste token in the Token field, or use token in `Authorization` header for API calls.
4. Click "Refresh Now" to collect current metrics and update charts.

## Notes
- SQLite DB `alerts.db` is created automatically.
- Sample logs placed under `data/sample.log` for `GET /api/analyze-log`