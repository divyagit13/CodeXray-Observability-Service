# app.py
from flask import Flask, request, jsonify, render_template
from werkzeug.security import generate_password_hash, check_password_hash
import uuid
from db import init_db, get_db_connection
from metrics import check_and_store_metrics, get_recent_metrics, get_recent_alerts, get_thresholds, update_thresholds
from log_analyzer import analyze_log

app = Flask(__name__, static_folder='static', template_folder='templates')

# Simple in-memory user/session store for the assignment
users = {}
sessions = {}  # token -> username

# init DB
init_db()

# ------------ Helpers ---------------
def require_auth(f):
    # decorator-like helper for simple route protection
    def wrapped(*args, **kwargs):
        token = request.headers.get('Authorization')
        if not token or token not in sessions:
            return jsonify({"error": "Unauthorized"}), 403
        return f(*args, **kwargs)
    wrapped.__name__ = f.__name__
    return wrapped

# ------------ Root & Dashboard ---------------
@app.route('/')
def index():
    return "CodeXray Observability Service running. Visit /dashboard after logging in."

@app.route('/dashboard')
def dashboard():
    # dashboard page (JS will call API endpoints for data)
    return render_template('dashboard.html')

# ------------ Phase 1: Log Analyzer ---------------
@app.route('/api/analyze-log', methods=['GET'])
@require_auth
def analyze_log_route():
    # path to sample log
    result = analyze_log("data/sample.log")
    return jsonify(result)

# ------------ Phase 2: Auth ---------------
@app.route('/api/register', methods=['POST'])
def register():
    data = request.json or {}
    username = data.get('username')
    pwd = data.get('password')
    if not username or not pwd:
        return jsonify({"error": "username and password required"}), 400
    if username in users:
        return jsonify({"error": "User exists"}), 400
    users[username] = generate_password_hash(pwd)
    return jsonify({"message": "registered"})

@app.route('/api/login', methods=['POST'])
def login():
    data = request.json or {}
    username = data.get('username')
    pwd = data.get('password')
    if not username or not pwd:
        return jsonify({"error": "username and password required"}), 400
    if username not in users or not check_password_hash(users[username], pwd):
        return jsonify({"error": "Invalid credentials"}), 401
    token = str(uuid.uuid4())
    sessions[token] = username
    return jsonify({"session_token": token})

@app.route('/api/validate-session', methods=['POST'])
def validate_session():
    token = (request.json or {}).get('token')
    return jsonify({"valid": bool(token in sessions)})

# ------------ Phase 3: Collect metrics ---------------
@app.route('/api/collect-metrics', methods=['POST'])
@require_auth
def collect_metrics_route():
    metrics, alerts = check_and_store_metrics()
    return jsonify({"metrics": metrics, "alerts_generated": alerts})

# ------------ Phase 4: Reporting API ---------------
@app.route('/api/summary', methods=['GET'])
@require_auth
def summary():
    # total alerts, breakdown by type, last N alert timestamps, average metric values for last 10 readings
    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("SELECT COUNT(*) as cnt FROM alerts")
    total_alerts = cur.fetchone()['cnt']

    cur.execute("SELECT type, COUNT(*) as cnt FROM alerts GROUP BY type")
    counts = {row['type']: row['cnt'] for row in cur.fetchall()}

    cur.execute("SELECT timestamp FROM alerts ORDER BY id DESC LIMIT 10")
    recent = [r['timestamp'] for r in cur.fetchall()]

    cur.execute("SELECT cpu, memory FROM metrics ORDER BY id DESC LIMIT 10")
    last_10 = cur.fetchall()
    conn.close()

    if last_10:
        avg_cpu = sum(r['cpu'] for r in last_10) / len(last_10)
        avg_mem = sum(r['memory'] for r in last_10) / len(last_10)
    else:
        avg_cpu = avg_mem = 0.0

    return jsonify({
        "total_alerts": total_alerts,
        "breakdown": counts,
        "recent_alert_timestamps": recent,
        "avg_cpu_last_10": round(avg_cpu, 2),
        "avg_mem_last_10": round(avg_mem, 2)
    })

# ------------ Metrics history & alerts APIs used by dashboard ---------------
@app.route('/api/metrics-history', methods=['GET'])
@require_auth
def metrics_history():
    limit = int(request.args.get('limit', 50))
    data = get_recent_metrics(limit=limit)
    return jsonify(data)

@app.route('/api/alerts', methods=['GET'])
@require_auth
def alerts_route():
    limit = int(request.args.get('limit', 100))
    data = get_recent_alerts(limit=limit)
    return jsonify(data)

# ------------ Config (thresholds) ---------------
@app.route('/api/config', methods=['GET', 'POST'])
@require_auth
def config_route():
    if request.method == 'GET':
        return jsonify(get_thresholds())
    data = request.json or {}
    cpu = data.get('cpu_threshold')
    mem = data.get('mem_threshold')
    # validate
    try:
        if cpu is not None:
            cpu = float(cpu)
        if mem is not None:
            mem = float(mem)
    except ValueError:
        return jsonify({"error": "thresholds must be numeric"}), 400
    update_thresholds(cpu_threshold=cpu, mem_threshold=mem)
    return jsonify({"message": "updated", "new_thresholds": get_thresholds()})

# ------------ Run ---------------
if __name__ == '__main__':
    app.run(debug=True)
