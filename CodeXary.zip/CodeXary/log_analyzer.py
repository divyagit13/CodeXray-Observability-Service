# log_analyzer.py
from collections import Counter
import re

def analyze_log(file_path):
    """
    Parses a log file and returns counts of log levels and top 5 errors.
    Assumes lines contain INFO/WARN/ERROR tokens.
    """
    log_counts = Counter()
    error_messages = Counter()
    level_pattern = re.compile(r'\b(INFO|WARN|ERROR)\b')

    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            m = level_pattern.search(line)
            if m:
                level = m.group(1)
                log_counts[level] += 1
                if level == "ERROR":
                    error_messages[line.strip()] += 1

    return {
        "log_counts": dict(log_counts),
        "top_5_errors": error_messages.most_common(5)
    }
